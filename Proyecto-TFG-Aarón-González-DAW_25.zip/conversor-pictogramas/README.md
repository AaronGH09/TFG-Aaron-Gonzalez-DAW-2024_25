Comandos para levantar cada apartado:
-Levantar frontend  npm run dev
-Levantar backend mvnw spring-boot:run

Librerias y API:
-En este proyecto los pictogramas son sacados atraves de la api de ARASAAC por lo que los derechos de los pictogrmas son de este.
-Api FullScreen para hacer como un bloqueo para que los niños al tocar las teclas no les sea tan facil salirse de la pagina.
-Librerias para poder exportar como imagen o pdf html2canvas jspdf. 
-Librerias para poder pasar de voz a texto speech api utilizando (SpeechRecognition y webkitSpeechRecognition) para una mejor compatibilidad
-Librerias para poder viajar o dirigirme entre la diferentes pages con react-router

AGRADECIMIENTOS
Los pictogramas usados en esta aplicación son parte de la colección ARASAAC, son propiedad del Gobierno de Aragón y han sido creados por Sergio Palao, se publican bajo Licencia Creative Commons (BY-NC-SA), autorizando su uso para fines sin ánimo lucrativo siempre que se cite la fuente, autor y se compartan bajo la misma licencia. 